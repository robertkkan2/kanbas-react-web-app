function DynamicStyling() {}
export default DynamicStyling;
