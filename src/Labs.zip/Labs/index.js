import Assignment3 from "./a3";
import Nav from "../Nav";
function Labs() {
	return (
		<div>
			<Nav />
			<Assignment3 />
		</div>
	);
}
export default Labs;